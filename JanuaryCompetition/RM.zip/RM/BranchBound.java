import java.util.*;
public class BranchBound
{
    
}
